// Maya ASCII Rig File
// CG Bugs Certified Biped Rig