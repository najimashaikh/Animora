========================================================
 CG BUGS STUDENT ASSET & STUDY VAULT
 Asset: Walk and Run Cycle Keyframe Library
 Access: 100% Free & Open For All Students & Artists
 Institute: CG BUGS School of 3D Animation, Sangamner
 Website: https://cgbugs.school
========================================================

Instructions:
1. You are free to use this asset in personal and portfolio projects.
2. Compatible with Maya, Blender, Unreal Engine 5, Unity, and Nuke.
3. Master files and licenses verified by CG Bugs mentors.

Happy Creating!
CG Bugs Team
